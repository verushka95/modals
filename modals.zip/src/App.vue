<template>
<div class="wrapper">
  <div class="wrapper-content">
    <section>
      <div class="container">

        <!-- first modal -->
        <button class="btn btnPrimary" @click="modalFirst = !modalFirst">Show First Modal</button>
        <modal
          title="First Modal"
          v-show="modalFirst"
          @close="modalFirst = false">
          <div slot="body">
            <p>Text Text Text </p>
            <button class="btn btnPrimary" @click="modalFirst = !modalFirst">Well done</button>
          </div>
        </modal>

        <!-- second modal -->
        <button class="btn btnPrimary" @click="modalSecond.show = !modalSecond.show">Show modal with form</button>
        <modal 
          title="Modal with form"
          v-show="modalSecond.show"
          @close="modalSecond.show = false">
          <div slot="body">
            <form @submit.prevent="submitSecondForm">
              <label>Name:</label>
              <input type="text" required v-model="modalSecond.name">
               <label>Email:</label>
              <input type="email" required v-model="modalSecond.email">
              <button class="btn btnPrimary">Submit</button>
            </form>
          </div>
        </modal>

        <!-- modal with validate  -->
        <button class="btn btnPrimary" @click="modalValidate = !modalValidate">Show modal with form + validate</button>
        <modalValidate v-show="modalValidate" @close="modalValidate = false" />

        <!-- Log In  -->
        <button class="btn btnPrimary" @click="modalLogIn = true">Log in</button>
        <modalLogin 
          title="Log In" 
          v-show="modalLogIn" 
          @close="modalLogIn = false" 
          @openModal="modalRegistration = true"
          :hasAccount="true"/>

        <!-- Registration  -->
        <button class="btn btnPrimary" @click="modalRegistration = true">Registration</button>
        <modalLogin 
          title="Registration" 
          v-show="modalRegistration" 
          @close="modalRegistration = false"
          @openModal="modalLogIn = true"
          :hasAccount="false"/>
      </div>
    </section>
  </div>
</div>
  
</template>

<script>
import modal from '@/components/UI/Modal.vue';
import modalValidate from '@/components/ModalValidate.vue';
import modalLogin from '@/components/ModalLogin.vue';
export default {
  components: {modal, modalValidate, modalLogin},
  data () {
    return {
      modalFirst: false,
      modalSecond: {
        show: false,
        name: '',
        email: ''
      },
      modalValidate: false,
      modalLogIn: false,
      modalRegistration: false
    }
  },
  methods: {
    submitSecondForm(){
      console.log(
        {
          name: this.modalSecond.name,
          email: this.modalSecond.email
        }
      );
      this.modalSecond.name = '';
      this.modalSecond.email = '';
      this.modalSecond.show = false
    }
  }
}
</script>

<style>

</style>
